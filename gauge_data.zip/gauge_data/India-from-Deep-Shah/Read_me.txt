%% Read Me file prepared 
by Deep Shah (contact: deep.shah@tamu.edu), 
Texas A&M University, 
last modified: 07/11/2025 %%

The "Basic_information_PLD_ID_with_WRIS_merged_deep" file contains 
reservoir name, state, longitude, latitude, and corresponding lake_id from SWOT Prior lake dataset.

The latitude and longitude data were compiled from various online sources, 
including the National Register of Large Dams (India; https://prsindia.org/files/bills_acts/bills_parliament/2019/National%20Register%20of%20Large%20Dams,%202019.pdf), 
the Geoportal of Indian Dams (GeoID) [https://wcl-iitgn.github.io/geoid/], and 
open-source data available on GitHub [https://gist.github.com/devdattaT/5f5c9e5b0fe425cf88fb20b61c78401d].

The "Monthly Reservoir Level & Storage Timeseries data for All agency for period 2023-01 to 2025-05" file contains
in-situ observations for most observed Indian reservoirs. This data is downloaded from https://indiawris.gov.in/wris/#/
The file contains data from all agencies compiled. More details on units can be found at https://indiawris.gov.in/downloads/Inventory%20of%20Water%20Data%20maintained%20by%20NWIC.pdf
If the link does not work, I have provided the pdf (with name: Inventory of Water Data maintained by NWIC) in the same folder.

Please note that the file titled "Monthly Reservoir Level & Storage Timeseries data for All Agencies for the period 2023-01 to 2025-05" contains 
more reservoirs than those listed in "Basic_information_PLD_ID_with_WRIS_merged_deep". Therefore, for validation purposes, 
kindly restrict the comparison to only those reservoirs present in "Basic_information_PLD_ID_with_WRIS_merged_deep".

You can use the "Reservoir Name" to locate corresponding in-situ data, and the "lake_id (PLD_SWOT)" to retrieve the relevant SWOT data.

Thank you.